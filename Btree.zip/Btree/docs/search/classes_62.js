var searchData=
[
  ['badbufferexception',['BadBufferException',['../classbadgerdb_1_1_bad_buffer_exception.html',1,'badgerdb']]],
  ['badgerdbexception',['BadgerDbException',['../classbadgerdb_1_1_badger_db_exception.html',1,'badgerdb']]],
  ['badindexinfoexception',['BadIndexInfoException',['../classbadgerdb_1_1_bad_index_info_exception.html',1,'badgerdb']]],
  ['badopcodesexception',['BadOpcodesException',['../classbadgerdb_1_1_bad_opcodes_exception.html',1,'badgerdb']]],
  ['badscanparamexception',['BadScanParamException',['../classbadgerdb_1_1_bad_scan_param_exception.html',1,'badgerdb']]],
  ['badscanrangeexception',['BadScanrangeException',['../classbadgerdb_1_1_bad_scanrange_exception.html',1,'badgerdb']]],
  ['blobfile',['BlobFile',['../classbadgerdb_1_1_blob_file.html',1,'badgerdb']]],
  ['btreeindex',['BTreeIndex',['../classbadgerdb_1_1_b_tree_index.html',1,'badgerdb']]],
  ['bufdesc',['BufDesc',['../classbadgerdb_1_1_buf_desc.html',1,'badgerdb']]],
  ['bufferexceededexception',['BufferExceededException',['../classbadgerdb_1_1_buffer_exceeded_exception.html',1,'badgerdb']]],
  ['bufhashtbl',['BufHashTbl',['../classbadgerdb_1_1_buf_hash_tbl.html',1,'badgerdb']]],
  ['bufmgr',['BufMgr',['../classbadgerdb_1_1_buf_mgr.html',1,'badgerdb']]],
  ['bufstats',['BufStats',['../structbadgerdb_1_1_buf_stats.html',1,'badgerdb']]]
];

var searchData=
[
  ['tuple',['tuple',['../structtuple.html',1,'']]]
];
